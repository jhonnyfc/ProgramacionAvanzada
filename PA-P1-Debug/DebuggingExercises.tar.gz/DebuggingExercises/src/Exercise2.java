
public class Exercise2 {
   
    public static int MAX_ELT = 20;
    
    public static void main(String[] args) 
    { 
        int[] array = new int[MAX_ELT];
        int i = 0, n =0;
        //generacion de un array ordenado
        while(i<MAX_ELT) {
            if( (int)Math.round(Math.random()) == 1)
            {
                array[i++] = n;
                n = array[i-1]+1+(int)(Math.random()*20);
            }
        }        
        //elige un elemento dentro del array para asegurarse que el elemento existe
        int key = array[(int)(Math.random()*(MAX_ELT-1))];
        
        /* pide al usuario de elegir un numero a ver si existe */
                
        int pos = binarySearch(array, key, 0, MAX_ELT);
        
        if(pos != -1)
            System.out.println("El elemento: " + key + " se encuentra al indice: " + pos);
        else
            System.out.println("No existe el elemento "+ key);
    }     
    
    public static int binarySearch(int array[], int key, int inic, int fin)
    {
        if(fin >= inic){
            
            int mid = inic + (fin - inic)/2; //Evita overflow
            
            if(array[mid] == key)
                return mid;
            
            else if(array[mid] < key)
                return binarySearch(array, key, mid + 1, fin);
            
            else if(array[mid] > key)
                return binarySearch(array, key, inic, mid - 1);
        }
        
        return -1;
    }    
}
