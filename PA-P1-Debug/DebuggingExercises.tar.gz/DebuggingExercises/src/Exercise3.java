import static DebuggingExercise4.i;
import java.util.Scanner;


public class Exercise3 {
 
    /* ejemplo para asegurar que funcione el algoritmo
        a: 2 1
           3 2
           1 2
  
        b: 3 2 4
           2 1 1  
    
           8 5 9 
           13 8 14 
           7 4 6 
    */
  public static void main(String[] args) {    

      int a[][] = {{2,1},{3, 2}, {1, 2}};
  
      int b[][] = {{3, 2, 4}, {2, 1, 1}};
      
      int rows1 = a.length;
      int columns1 = a.length;
      int rows2 = columns1;
      int columns2 = rows1;
      
      int[][] c = new int[columns2][columns2];
      multiplyMatrix(a, rows1, columns1, b, rows2, columns2, c);

        
      printMatrix(c,columns2,columns2);
       
    }
 
    static void multiplyMatrix(int[][] a, int rows1, int columns1, int[][] b, int rows2, int columns2, int[][] result)
    {
        int i = 0, j = 0, k = 0;
        {
        if (i >= columns2)
            return;
  
        if (j < SIZE)
        {
            //aqui se calcula el resultado de una casilla de la matriz resultado
            //que es la suma de las multiplicaciones de la linea de la matriz A con la columna de la matriz B
            if (k < SIZE)
            {
                result[i][j] += a[i][k] * b[k][j];
                k++;  
                multiplyMatrix(a, b, result);
            }
            //aqui pasamos a la siguiente columna
            k = 0;
            j++;
            multiplyMatrix(a, b, result);
        }
        //aqui pasamos a la siguiente linea
        j = 0;
        i++;
        multiplyMatrix(a, b, result);
    } 
    
    static void printMatrix(int[][] m, int rows, int columns) {
        
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < columns; j++)            
                System.out.print(m[i][j]+" ");
  
            System.out.println();
        } 
    }    
}
