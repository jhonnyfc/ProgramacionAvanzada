class DebuggingExercise2 
{ 
    public static void main(String[] args) 
    { 
        int result = fib(8);
        System.out.println("The result is: "+result); 
    } 
    
    static int fib(int n) {        
        int f = 0;
        int f0 = 0;
        int f1 = 1;   
        System.out.print("Fibonacci of " + n +": " + f0 + " " + f1);                
        while (n > 1) {
            n--;
            f = f0 + f1;
            f0 = f1;
            f1 = f; 
            System.out.print(" " + f);
        }
        System.out.println();
        return f; 
    }    
}