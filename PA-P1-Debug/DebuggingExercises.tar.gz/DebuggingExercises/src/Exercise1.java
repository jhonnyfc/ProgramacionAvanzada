
public class Exercise1 {

    public static void main(String[] args) 
    { 
        int result = fib(8);
        System.out.println("The result is: "+result); 
    } 
    
    static int fib(int n) {        
        
        /* implementa aqui el calculo de Fibonacci con recursión */
        return -1;
    }     
}
