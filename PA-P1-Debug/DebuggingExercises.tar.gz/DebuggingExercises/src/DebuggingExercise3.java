

class DebuggingExercise3 {

    public static int MAX_ELT = 20;
    
    public static void main(String[] args) {
        
        int[] array = new int[MAX_ELT];
        //generación de numeros aleatorios negativos
        for(int i = 0; i < MAX_ELT-1; ++i)
        {
	      array[i] = -(int)(Math.random()*1000);
        }
        
        long max = findMaxElt(array, 0, Long.MIN_VALUE);    
        System.out.println("the max elt is: " + max);
    }
        
    //metodo de busqueda del elemento de mayor valor
    public static long findMaxElt(int[] array, int pos, long max) {    
        if(pos < MAX_ELT-1)
        {
            
            if(array[pos] > max)
                max = array[pos];
            max = findMaxElt(array, ++pos, max);
        }
        return max;
    }    

}
