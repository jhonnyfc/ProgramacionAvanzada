

class DebuggingExercise3 {

    public static int MAX_ELT = 20;
    
    public static void main(String[] args) {
        
        int[] array = new int[MAX_ELT];
        //generación de numeros aleatorios negativos
        for(int i=0; i<MAX_ELT-1;++i)
        {
	      array[i] = -(int)(Math.random()*1000);
        }
        
        int max = findMaxElt(array,0, Integer.MIN_VALUE);    
        System.out.println("the max elt is: " + max);
    }
        
    //metodo de busqueda del elemento de mayor valor
    static int findMaxElt(int[] array, int pos, int max) {    
        if(pos < MAX_ELT-1)
        {
            max = findMaxElt(array, pos++, max);
            if(array[pos] > max)
                max = array[pos];
            
        }
        return max;
    }    

}
