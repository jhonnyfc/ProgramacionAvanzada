

class DebuggingExercise4 {

    public static int SIZE = 3;
    
    public static void main(String[] args) {
        
        int a[][] = { {1, 2, 3},
                      {4, 5, 6},
                      {7, 8, 9}};
  
        int b[][] = { {1, 2, 3},
                      {4, 5, 6},
                      {7, 8, 9} };
  
        int[][] c = new int[SIZE][SIZE];
        multiplyMatrix(a, b, c);

        
        printMatrix(c);
        //el resultado debería ser
        // 30 36 42 
        // 66 81 96 
        // 102 126 150
       
    }
        
    public static int i = 0, j = 0, k = 0;
     
    static void multiplyMatrix(int[][] a, int[][] b, int[][] result)
    {
        if (i >= SIZE)
            return;
  
        if (j <= SIZE)
        {
            //aqui se calcula el resultado de una casilla de la matriz resultado
            //que es la suma de las multiplicaciones de la linea de la matriz A con la columna de la matriz B
            if (k <= SIZE)
            {
                result[i][i] += a[i][k] * b[k][j];
                k++;  
                multiplyMatrix(a, b, result);
            }
            //aqui pasamos a la siguiente columna
            k = 0;
            j++;
            multiplyMatrix(a, b, result);
        }
        //aqui pasamos a la siguiente linea
        j = 0;
        i++;
        multiplyMatrix(a, b, result);
    } 
    
    static void printMatrix(int[][] m) {
        
        for (int i = 0; i < SIZE; i++)            
        {
            for (int j = 0; j < SIZE; j++)
                System.out.print(m[i][j]+" ");
  
            System.out.println();
        } 
    }

}
