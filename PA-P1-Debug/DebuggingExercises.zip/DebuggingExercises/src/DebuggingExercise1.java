
import java.util.Scanner;

public class DebuggingExercise1 {
    
    public static void main(String[] args) 
    { 
        Scanner sc = new Scanner(System.in);
        System.out.print("Entra tu nombre: "); 
        String name = sc.next();
        System.out.println();
        System.out.print("Entra tu edad: "); 
        int age = Integer.parseInt(sc.next());
        System.out.println();        
        System.out.print("Entra tu altura (m): "); 
        float height = Float.parseFloat(sc.next());
        System.out.println();        
        System.out.print("Entra tu peso (kg): "); 
        float weight = Float.parseFloat(sc.next());
        System.out.println(name + ", tu IMC es:" + weight/(height*height));
        displayIMC(age);
    }   
    
    static void displayIMC(int age) {
        if(age < 25)
            System.out.println("El IMC correspondiente a tu edad debe ir entre 19 y 24");
        else if( age <= 35)
            System.out.println("El IMC correspondiente a tu edad debe ir entre 20 y 25");
        else if( age <= 45)
            System.out.println("El IMC correspondiente a tu edad debe ir entre 21 y 26");
        else if( age <= 55)
            System.out.println("El IMC correspondiente a tu edad debe ir entre 22 y 27");
        else if( age <= 65)
            System.out.println("El IMC correspondiente a tu edad debe ir entre 23 y 28");
        else
            System.out.println("El IMC correspondiente a tu edad debe ir entre 24 y 29");        
        
    }
}
