
import java.util.Scanner;


public class Exercise3 {
 
    /* ejemplo para asegurar que funcione el algoritmo
        a: 2 1
           3 2
           1 2
  
        b: 3 2 4
           2 1 1  
    
           8 5 9 
           13 8 14 
           7 4 6 
    */
  public static void main(String[] args) {    
      
      int rows1 = 0;
      int columns1 = 0;
      
      /* pide al usuario el tamaño de la primera matrix */
      
      //la segunda matriz tendrá automaticamente un tamaño inverso
      int rows2 = columns1;
      int columns2 = rows1;

      int a[][] = fillMatrix(rows1,columns1);
  
      int b[][] = fillMatrix(rows2,columns2);
  
        
      int[][] c = new int[columns2][columns2];
      multiplyMatrix(a, rows1, columns1, b, rows2, columns2, c);

        
      printMatrix(c,columns2,columns2);
       
    }
        
    static int[][] fillMatrix(int rows, int columns) {
        int[][] m = new int[rows][columns];
        
        /* pide al usuario que rellene una matriz aqui */
        
        return m;
    }
    
    
    static void multiplyMatrix(int[][] a, int rows1, int columns1, int[][] b, int rows2, int columns2, int[][] result)
    {
        /* adaptar el codigo del ejercicio DebuggingExercise4
         * para que funcione con matrices de tamaño distintos
        */
    } 
    
    static void printMatrix(int[][] m, int rows, int columns) {
        
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < columns; j++)            
                System.out.print(m[i][j]+" ");
  
            System.out.println();
        } 
    }    
}
