/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p2_ej3;

/**
 *
 * @author alumno
 */
public class Geometry3DFactory {
    
    //create cube
    public Geometry createRectangle(float[] params){
       
        return;
    }
    //create tetrahedron
    Geometry createTriangle(float[] params){
        
        return ;
    }
    
    //create sphere
    public Geometry createCircle(float[] params){
    
        return;
    }
    
    
    
}
