/*
Se puede hacer una clase poniendo en las opcieones enum.(Esta clase 
no se usa porque ya esta en GeometryFactory)
Si se hace el enum en una clase solo sirve para esa clase.
*/
package Ej3;
/**
 *
 * @author alumno
 */
public class Dimension {
    
}
